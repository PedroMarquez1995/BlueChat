# BlueChat · Rediseño 2.0 · APK de mensajería Bluetooth experimental

**Estado: prototipo alfa 0.2.0 (rediseño de interfaz 2.0) de código fuente.** Diseñado para compilar con GitHub Actions; NO se ha compilado con el Android SDK en este entorno ni se ha validado en teléfonos reales. Que el proyecto tenga motor BLE no prueba que un camino A → B → C funcione en tu hardware. Se requiere probar y depurar con al menos tres equipos.


## Novedades del rediseño visual 2.0

- Nueva pantalla de bienvenida, logotipo e icono adaptativo; interfaz con identidad azul eléctrico y azul profundo.
- Tema oscuro predeterminado y opciones **Oscuro / Claro / Sistema** persistidas localmente.
- Navegación de cuatro pestañas con diseño Material 3: **Chats, Cercanos, Red Mesh y Ajustes**.
- Tarjeta de conectividad con número real de vecinos BLE; activación/desactivación usando el servicio existente.
- Lista de conversaciones ordenada por actividad, con la última vista previa real del mensaje local cifrado y estado de entrega.
- Pantalla de chat con burbujas, campos mejorados, confirmaciones reales y desplazamiento al último mensaje.
- Pantalla de cercanos que distingue entre **identidades conocidas** y **vecinos Bluetooth**, sin simular presencia.
- Dashboard Mesh con métricas reales disponibles y aclaraciones sobre aquellas que el motor todavía no recopila.
- Ajustes funcionales para alias, apariencia, copiado de huella criptográfica y apertura de los permisos de notificaciones.
- El núcleo BLE, el protocolo, los permisos y la base de datos v1 se conservan. Se agregan solamente consultas de lectura para la interfaz.

### Actualizar tu proyecto que ya está en GitHub (desde el teléfono)

El workflow que ya te compiló busca un archivo llamado **`BlueChat-Android-Project.zip`** en la raíz de GitHub. Por eso la entrega principal del rediseño conserva **exactamente ese nombre de archivo** y la misma carpeta interior.

1. En la pestaña **Code** abre el ZIP antiguo, elige la opción para eliminar el archivo y confirma el commit. No borres `.github/workflows/build.yml`.
2. Sube el nuevo **`BlueChat-Android-Project.zip`** a la raíz del repositorio y confirma el commit.
3. Ejecuta **Actions → Compilar BlueChat APK → Run workflow** (o revisa la ejecución automática del push).
4. Descarga la nueva APK del artefacto **BlueChat-Debug-APK**.

**Nota sobre la instalación:** GitHub Actions firma cada compilación de depuración con una clave debug que puede cambiar entre ejecuciones. Si Android muestra un error de firma al actualizar, tendrás que desinstalar la APK anterior antes de instalar la nueva. Desinstalar elimina la identidad criptográfica y los mensajes guardados (no hay respaldo habilitado). Para actualizaciones sin pérdida de datos es necesario implementar firma estable con una clave de lanzamiento protegida por Secrets de GitHub; esto no forma parte de esta versión experimental.

**Alcance de validación:** esta entrega contiene código fuente, no una APK ya compilada. Se validó la estructura, los recursos XML y los archivos empaquetados. La compilación Android real y el funcionamiento BLE/Mesh seguirán comprobándose en GitHub Actions y dispositivos físicos.

## Qué está implementado en el código

- App Android nativa, Kotlin, Compose Material 3; Android 8.0+.
- Sin permiso de INTERNET, ni Wi-Fi, ni cuentas online, ni servidor.
- Perfil local, alias y huella de identidad.
- Claves P-256 para ECDH y ECDSA, AES-256-GCM para cada mensaje.
- Claves privadas y mensajes locales cifrados con una clave AES de Android Keystore.
- Publicidad y escaneo BLE, servidor y cliente GATT, notificaciones y escrituras serializadas por enlace.
- Fraccionamiento de mensajes GATT, reconstrucción, límite de saltos de 5, TTL, duplicados, almacenamiento y retransmisión entre vecinos.
- Intercambio de perfiles firmados que pueden circular por intermediarios; se puede iniciar un chat con identidades descubiertas indirectamente.
- Confirmación firmada del destinatario, diferenciada del envío a un vecino.
- Servicio visible de primer plano, conversaciones, contactos, estadísticas básicas y ajustes del alias.
- Pruebas unitarias del protocolo de fragmentación y saltos.
- Workflow para compilar en Actions incluso si el repositorio contiene **solo el ZIP**.

## Límites conocidos (importante)

- **No se garantiza funcionamiento Mesh real.** La capa BLE debe probarse y ajustarse en teléfonos con diferentes radios y restricciones de fabricantes.
- El envío de texto no confirma recepción hasta que llegue una confirmación firmada. Si no hay ruta, puede permanecer pendiente y finalmente caducar.
- Los contactos se aceptan automáticamente por su clave pública (TOFU); se muestra la huella para comparación manual, pero no hay verificación QR, anti-Sybil, protección contra análisis de tráfico ni revisión profesional de seguridad. No utilizar para comunicaciones sensibles o de emergencia.
- No hay grupos, fotos, voz, llamadas, etiquetas de cercanía por identidad, emparejamiento formal, enrutamiento óptimo, ni interfaz para limpiar historial.
- El servicio en primer plano no evita que Android o el fabricante interrumpan BLE en segundo plano.
- Algunas versiones de Android limitan publicidad BLE simultánea con escaneo o conexiones GATT.
- No hay protocolo de control de congestión avanzado. Solo 6 conexiones cliente, 1000 fragmentos por cola y 600 paquetes persistidos. El funcionamiento puede empeorar en redes grandes.
- Las notificaciones de nuevos mensajes requieren autorización de notificaciones en Android 13+; desde Ajustes del teléfono > Aplicaciones > BlueChat > Notificaciones.
- No hay garantía de soporte en Android 8-11 sin haber probado permisos y publicidad BLE específicos.
- La aplicación puede descubrir y retransmitir claves públicas y alias a personas fuera del rango directo; son metadatos públicos en el protocolo.
- No se incluye `gradle-wrapper.jar`: para evitar distribuir una copia no verificada del binario, el workflow instala Gradle 8.11.1 mediante la acción oficial `gradle/actions/setup-gradle`. Es suficiente para compilar en Actions sin instalar nada local.

## Compilar desde el navegador de GitHub — método fácil con ZIP

1. Crea un repositorio nuevo y vacío en GitHub (por ejemplo, `BlueChat`).
2. En **Add file > Upload files**, sube **BlueChat-Android-Project.zip** SIN extraerlo y haz **Commit changes**.
3. En **Add file > Create new file**, en el campo del nombre escribe exactamente `.github/workflows/build.yml`.
4. Copia el contenido del archivo **workflow-para-pegar-en-github.yml** que te entregamos por separado. Pégalo y haz **Commit changes**.
5. En GitHub entra a **Actions > Compilar BlueChat APK > Run workflow**.
6. Al terminar correctamente, entra en la ejecución y baja **BlueChat-Debug-APK** en **Artifacts**.
7. Dentro del artefacto estará `app-debug.apk`. En Android habilita instalar APK desde la fuente con la que lo abriste, si el teléfono lo solicita.

### Método alternativo: repositorio con archivos descomprimidos

Sube la **carpeta interna** del ZIP manteniendo `settings.gradle.kts`, `app/` y `.github/` en la raíz del repositorio. El workflow ya incluido también compila esa estructura. GitHub **no descomprime automáticamente** un ZIP que subes como archivo: por eso recomendamos el primer método desde un móvil.

## Prueba entre teléfonos

1. Instala la misma APK en tres teléfonos que admitan BLE con publicidad múltiple.
2. Activa Bluetooth y concede permisos de dispositivos cercanos; en Android 8-11 concede ubicación a la aplicación para escanear BLE (no enviamos coordenadas GPS).
3. Abre BlueChat y pulsa **Activar Bluetooth Mesh** en cada equipo. Mantén la app abierta en las pruebas iniciales.
4. Acerca A a B para intercambiar perfiles. Acerca C a B, mientras mantienes A fuera del rango de C.
5. Comprueba que el contacto C aparezca en A tras circular su perfil por B. Escribe en A para C.
6. Verifica que C recibe texto; después observa si la confirmación regresa a A. Si falla, consulta los logs Android (`tag BlueChat`) y la lista de permisos.
7. Repite con radio Bluetooth libre, pantalla apagada y distintas marcas; documenta el resultado, porque son pruebas todavía pendientes.

## Diseño del protocolo (v1)

Cada paquete JSON firmado tiene `id,type,sender,recipient,created,expires,limit,hops,payload,signature`. Solo `hops` cambia al retransmitir. La firma ECDSA cubre todos los otros campos. Tipos `PROFILE`, `CHAT`, `ACK`. Los mensajes CHAT usan AES-GCM tras derivar una clave por ECDH y HKDF-SHA256 asociada al ID de mensaje. Los ACK solo acreditan recepción por parte del destinatario original; no acreditan lectura. Un paquete TTL caducado, excedido en saltos o duplicado es descartado.

### Matriz de seguridad pendiente

- Verificación cara a cara / QR y prevención de sustitución de perfiles.
- Resistencia a abuso, denegación de servicio, retención de metadatos y auditoría criptográfica.
- Política de límites por usuario y optimización de reconexiones.
- Revisar comportamiento con horario del equipo incorrecto.

**Desarrollo de referencia; sin garantías de comunicación, disponibilidad o confidencialidad profesional.**
