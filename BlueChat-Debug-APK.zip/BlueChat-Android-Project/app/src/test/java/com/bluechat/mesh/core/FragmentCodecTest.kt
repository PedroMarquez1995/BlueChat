package com.bluechat.mesh.core

import org.junit.Assert.*
import org.junit.Test

class FragmentCodecTest {
    @Test fun roundTripWithLegacyMtu() {
        val bytes = "Mensaje BlueChat de prueba ".repeat(30).toByteArray()
        val frames = FragmentCodec.split(bytes)
        val assembler = FragmentAssembler()
        var output: ByteArray? = null
        frames.reversed().forEach { frame ->
            assertTrue(frame.size <= 20)
            val part = assembler.accept(frame)
            if (part != null) output = part
        }
        assertArrayEquals(bytes, output)
    }
    @Test fun ttlAndHopLimit() {
        val p = Packet("id", "CHAT", "abc", "def", 100, 999_999, 2, 0, "a", "sig")
        assertTrue(p.canForward(10))
        assertTrue(p.relayed().canForward(10))
        assertFalse(p.relayed().relayed().canForward(10))
        assertFalse(p.canForward(1_000_000))
        assertEquals(p.signable(), p.relayed().signable())
    }
    @Test(expected = IllegalArgumentException::class)
    fun rejectsMessageTooLarge() { FragmentCodec.split(ByteArray(32_001)) }
}
