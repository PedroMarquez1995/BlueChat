package com.bluechat.mesh.core

import java.security.SecureRandom

/** BLE application framing. Each fragment fits ATT MTU 23 (20 bytes). Larger MTUs are used if available. */
object FragmentCodec {
    const val HEADER = 5
    const val MAX_PAYLOAD = 32_000
    private val random = SecureRandom()
    fun split(message: ByteArray, mtu: Int = 23): List<ByteArray> {
        require(message.isNotEmpty() && message.size <= MAX_PAYLOAD)
        val chunkSize = (mtu - 3 - HEADER).coerceIn(1, 240)
        val count = (message.size + chunkSize - 1) / chunkSize
        require(count in 1..255) { "Too many fragments for selected MTU" }
        val code = random.nextInt(65_536)
        return (0 until count).map { index ->
            val from = index * chunkSize
            val part = message.copyOfRange(from, minOf(message.size, from + chunkSize))
            byteArrayOf(0xBC.toByte(), (code ushr 8).toByte(), code.toByte(), index.toByte(), count.toByte()) + part
        }
    }
}

/** A reassembler must be scoped to one peer/link. Reject stale and oversized incomplete messages. */
class FragmentAssembler {
    private data class Partial(val total: Int, val pieces: Array<ByteArray?>, var time: Long)
    private val inflight = mutableMapOf<Int, Partial>()
    @Synchronized fun accept(frame: ByteArray, now: Long = System.currentTimeMillis()): ByteArray? {
        if (frame.size < FragmentCodec.HEADER || frame[0] != 0xBC.toByte()) return null
        inflight.entries.removeAll { now - it.value.time > 30_000 }
        if (inflight.size > 12) inflight.clear()
        val code = ((frame[1].toInt() and 255) shl 8) or (frame[2].toInt() and 255)
        val index = frame[3].toInt() and 255
        val total = frame[4].toInt() and 255
        if (total == 0 || index >= total || frame.size > 245) return null
        val p = inflight.getOrPut(code) { Partial(total, arrayOfNulls(total), now) }
        if (p.total != total) { inflight.remove(code); return null }
        p.time = now
        p.pieces[index] = frame.copyOfRange(FragmentCodec.HEADER, frame.size)
        if (p.pieces.any { it == null }) return null
        inflight.remove(code)
        val count = p.pieces.sumOf { it!!.size }
        if (count > FragmentCodec.MAX_PAYLOAD) return null
        val result = ByteArray(count)
        var offset = 0
        p.pieces.forEach { piece -> piece!!.copyInto(result, offset); offset += piece.size }
        return result
    }
}
