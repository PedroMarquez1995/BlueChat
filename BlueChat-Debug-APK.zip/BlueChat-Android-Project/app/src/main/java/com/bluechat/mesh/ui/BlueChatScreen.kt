package com.bluechat.mesh.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bluechat.mesh.core.MeshUiState
import com.bluechat.mesh.db.Contact

/** UI-only container. Existing MeshCore callbacks are used without altering Bluetooth behavior. */
@Composable
fun BlueChatScreen(
    state: MeshUiState,
    selfId: String,
    alias: String,
    themeMode: String,
    onToggleMesh: () -> Unit,
    onSelect: (String?) -> Unit,
    onSend: (Contact, String) -> Unit,
    onRename: (String) -> Unit,
    onThemeChanged: (String) -> Unit,
    onOpenNotificationSettings: () -> Unit
) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val selectedContact = state.contacts.firstOrNull { it.id == state.selected }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            AppHeader(
                selected = selectedContact,
                hasSelection = state.selected != null,
                state = state,
                alias = alias,
                onBack = { onSelect(null) },
                onPower = onToggleMesh,
                onProfile = { tab = 3 }
            )
        },
        bottomBar = {
            if (state.selected == null) BlueNavigation(tab) { tab = it }
        },
        floatingActionButton = {
            if (state.selected == null && tab == 0 && state.contacts.isNotEmpty()) {
                ExtendedFloatingActionButton(
                    onClick = { tab = 1 },
                    containerColor = Indigo,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Nuevo chat", fontWeight = FontWeight.SemiBold) }
                )
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (state.selected != null) {
                if (selectedContact == null) {
                    EmptyPanel(
                        icon = Icons.Default.PersonOff,
                        title = "Contacto no disponible",
                        description = "Este contacto ya no se encuentra en tu lista local."
                    )
                } else {
                    ConversationPage(selectedContact, state.messages, onSend)
                }
            } else {
                when (tab) {
                    0 -> ChatsPage(state, onToggleMesh, onSelect) { tab = 1 }
                    1 -> NearbyPage(state, onToggleMesh, onSelect)
                    2 -> MeshPage(state, onToggleMesh)
                    else -> SettingsPage(selfId, alias, state, themeMode, onRename,
                        onThemeChanged, onToggleMesh, onOpenNotificationSettings)
                }
            }
        }
    }
}

@Composable
private fun AppHeader(
    selected: Contact?, hasSelection: Boolean, state: MeshUiState, alias: String,
    onBack: () -> Unit, onPower: () -> Unit, onProfile: () -> Unit
) {
    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 1.dp) {
        Row(
            Modifier.fillMaxWidth().height(78.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (hasSelection) {
                IconButton(onClick = onBack, modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Volver")
                }
                InitialAvatar(selected?.name ?: "?", 44.dp)
            } else {
                AppMark()
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    selected?.name ?: "BlueChat",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (hasSelection) "Cifrado · Entrega sujeta a la red" else
                        if (state.active) "Conectados sin Internet" else "Tu mensajería offline",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
            if (!hasSelection) {
                IconButton(onClick = onPower) {
                    Icon(
                        Icons.Default.PowerSettingsNew,
                        contentDescription = if (state.active) "Detener red" else "Activar red",
                        tint = if (state.active) Success else MaterialTheme.colorScheme.primary
                    )
                }
                Box(Modifier.clip(CircleShape).clickable(onClick = onProfile)) {
                    InitialAvatar(alias, 40.dp)
                }
            }
        }
    }
}

@Composable
private fun AppMark() {
    Box(
        modifier = Modifier.size(45.dp).clip(RoundedCornerShape(15.dp)).background(Indigo),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Default.Bluetooth, contentDescription = null,
            tint = Color.White, modifier = Modifier.size(28.dp))
    }
}

@Composable
private fun BlueNavigation(selected: Int, onSelect: (Int) -> Unit) {
    data class Nav(val label: String, val icon: ImageVector)
    val destinations = listOf(
        Nav("Chats", Icons.Default.ChatBubbleOutline),
        Nav("Cercanos", Icons.Default.PeopleOutline),
        Nav("Red Mesh", Icons.Default.Hub),
        Nav("Ajustes", Icons.Default.Settings)
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 1.dp) {
        destinations.forEachIndexed { index, destination ->
            NavigationBarItem(
                selected = selected == index,
                onClick = { onSelect(index) },
                icon = { Icon(destination.icon, contentDescription = null) },
                label = { Text(destination.label) },
                alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Indigo,
                    selectedTextColor = MaterialTheme.colorScheme.onSurface,
                    indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

@Composable
internal fun InitialAvatar(name: String, size: androidx.compose.ui.unit.Dp = 52.dp) {
    Surface(
        modifier = Modifier.size(size), shape = CircleShape,
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                name.trim().take(1).ifBlank { "?" }.uppercase(),
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
        }
    }
}

@Composable
internal fun SectionHeading(title: String, trailing: String? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f))
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
internal fun LabelPill(text: String, active: Boolean) {
    val background = if (active) Success.copy(alpha = 0.14f)
        else MaterialTheme.colorScheme.surfaceVariant
    val foreground = if (active) Success else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(shape = CircleShape, color = background) {
        Row(Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.size(6.dp).clip(CircleShape).background(foreground))
            Text(text, color = foreground, style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
internal fun EmptyPanel(icon: ImageVector, title: String, description: String, action: (@Composable () -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 45.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(shape = RoundedCornerShape(26.dp), color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(84.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(40.dp))
            }
        }
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(description, color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (action != null) action()
    }
}

@Composable
internal fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(23.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        content = { Column(Modifier.padding(18.dp), content = content) }
    )
}
