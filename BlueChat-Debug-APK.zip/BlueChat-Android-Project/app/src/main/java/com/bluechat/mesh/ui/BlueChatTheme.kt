package com.bluechat.mesh.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

internal val Electric = Color(0xFF38BDF8)
internal val Indigo = Color(0xFF2563EB)
internal val Night = Color(0xFF0B1120)
internal val NightSurface = Color(0xFF151F32)
internal val NightOutline = Color(0xFF293548)
internal val Success = Color(0xFF22C55E)
internal val SoftText = Color(0xFF94A3B8)

private val DarkPalette = darkColorScheme(
    primary = Electric,
    onPrimary = Night,
    primaryContainer = Color(0xFF17385D),
    onPrimaryContainer = Color(0xFFD9F3FF),
    secondary = Color(0xFF93BBF0),
    onSecondary = Night,
    secondaryContainer = Color(0xFF24354F),
    onSecondaryContainer = Color(0xFFD8E7FF),
    background = Night,
    onBackground = Color(0xFFF8FAFC),
    surface = NightSurface,
    onSurface = Color(0xFFF8FAFC),
    surfaceVariant = Color(0xFF202D44),
    onSurfaceVariant = SoftText,
    outline = NightOutline,
    error = Color(0xFFFCA5A5)
)

private val LightPalette = lightColorScheme(
    primary = Indigo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF133261),
    secondary = Color(0xFF087EB5),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD7EFFB),
    onSecondaryContainer = Color(0xFF16445B),
    background = Color(0xFFF4F7FB),
    onBackground = Color(0xFF0B1730),
    surface = Color.White,
    onSurface = Color(0xFF18253D),
    surfaceVariant = Color(0xFFEAF0F8),
    onSurfaceVariant = Color(0xFF64748B),
    outline = Color(0xFFD9E3F0)
)

@Composable
fun BlueChatTheme(mode: String, content: @Composable () -> Unit) {
    val useDark = when (mode) {
        "light" -> false
        "system" -> isSystemInDarkTheme()
        else -> true
    }
    MaterialTheme(colorScheme = if (useDark) DarkPalette else LightPalette,
        typography = Typography(), content = content)
}
