package com.bluechat.mesh.core

/** Signed fields must not change during forwarding. `hops` is the only mutable field. */
data class Packet(
    val id: String,
    val type: String,
    val sender: String,
    val recipient: String,
    val created: Long,
    val expires: Long,
    val limit: Int,
    val hops: Int,
    val payload: String,
    val signature: String
) {
    fun signable(): String = listOf(id, type, sender, recipient, created.toString(),
        expires.toString(), limit.toString(), payload).joinToString("\n")
    fun canForward(now: Long = System.currentTimeMillis()) = now < expires && hops < limit && limit in 1..8
    fun relayed() = copy(hops = hops + 1)
}
