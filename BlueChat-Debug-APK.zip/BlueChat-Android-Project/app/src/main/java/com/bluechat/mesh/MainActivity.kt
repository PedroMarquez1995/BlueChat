package com.bluechat.mesh

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import com.bluechat.mesh.ui.BlueChatScreen
import com.bluechat.mesh.ui.BlueChatTheme
import com.bluechat.mesh.ui.WelcomePage

/** Android permission and lifecycle bridge. BLE / Mesh behavior remains in MeshCore. */
class MainActivity : ComponentActivity() {
    private val app get() = application as BlueChatApp
    private var themePreference by mutableStateOf("dark")
    private var visibleAlias by mutableStateOf("")
    private var hasSeenWelcome by mutableStateOf(false)

    private val required: Array<String> get() = if (Build.VERSION.SDK_INT >= 31) arrayOf(
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_ADVERTISE
    ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (required.all { permission -> checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED }) {
            requestBluetooth()
        }
    }
    private val enableBluetooth = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (bluetoothEnabled()) startMesh()
    }
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        // Background BLE still works in permitted situations when notification permission is declined.
        launchMeshService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("bluechat_design", MODE_PRIVATE)
        themePreference = prefs.getString("theme", "dark") ?: "dark"
        visibleAlias = app.identity.alias
        hasSeenWelcome = prefs.getBoolean("welcome_complete", false)
        setContent {
            val state by app.core.ui.collectAsState()
            BlueChatTheme(themePreference) {
                if (!hasSeenWelcome) {
                    WelcomePage(onContinue = {
                        prefs.edit().putBoolean("welcome_complete", true).apply()
                        hasSeenWelcome = true
                    })
                } else BlueChatScreen(
                    state = state,
                    selfId = app.identity.id,
                    alias = visibleAlias,
                    themeMode = themePreference,
                    onToggleMesh = { if (state.active) stopMesh() else checkPermissions() },
                    onSelect = app.core::choose,
                    onSend = app.core::sendMessage,
                    onRename = { name ->
                        app.core.updateAlias(name)
                        visibleAlias = app.identity.alias
                    },
                    onThemeChanged = { mode ->
                        if (mode in setOf("dark", "light", "system")) {
                            themePreference = mode
                            prefs.edit().putString("theme", mode).apply()
                        }
                    },
                    onOpenNotificationSettings = {
                        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        }
                        startActivity(intent)
                    }
                )
            }
        }
    }

    private fun checkPermissions() {
        val missing = required.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissions.launch(missing.toTypedArray()) else requestBluetooth()
    }

    @SuppressLint("MissingPermission")
    private fun bluetoothEnabled(): Boolean =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true

    @SuppressLint("MissingPermission")
    private fun requestBluetooth() {
        if (bluetoothEnabled()) startMesh()
        else enableBluetooth.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
    }

    private fun startMesh() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else launchMeshService()
    }

    private fun launchMeshService() {
        startForegroundService(Intent(this, MeshForegroundService::class.java))
    }

    private fun stopMesh() {
        stopService(Intent(this, MeshForegroundService::class.java))
    }
}
