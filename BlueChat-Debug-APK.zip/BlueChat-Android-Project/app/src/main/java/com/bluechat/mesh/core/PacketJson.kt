package com.bluechat.mesh.core

import org.json.JSONObject

object PacketJson {
    fun encode(packet: Packet): String = JSONObject().apply {
        put("version", 1); put("id", packet.id); put("type", packet.type)
        put("sender", packet.sender); put("recipient", packet.recipient)
        put("created", packet.created); put("expires", packet.expires)
        put("limit", packet.limit); put("hops", packet.hops)
        put("payload", packet.payload); put("signature", packet.signature)
    }.toString()
    fun decode(value: String): Packet? = try {
        val j = JSONObject(value)
        if (j.getInt("version") != 1) null else Packet(
            j.getString("id"), j.getString("type"), j.getString("sender"), j.getString("recipient"),
            j.getLong("created"), j.getLong("expires"), j.getInt("limit"), j.getInt("hops"),
            j.getString("payload"), j.getString("signature")
        ).takeIf { it.id.length in 1..80 && it.sender.length == 64 && it.hops in 0..8 &&
            it.limit in 1..8 && it.payload.length < 24_000 && it.type in setOf("PROFILE", "CHAT", "ACK") }
    } catch (_: Exception) { null }
}
