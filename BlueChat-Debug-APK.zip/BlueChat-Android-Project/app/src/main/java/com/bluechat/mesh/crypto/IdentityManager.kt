package com.bluechat.mesh.crypto

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** P-256 ECDH for confidentiality and ECDSA for identity. Private key blobs encrypted at rest. */
class IdentityManager(context: Context) {
    private val preferences = context.getSharedPreferences("bluechat_identity", Context.MODE_PRIVATE)
    private val secureKey: SecretKey by lazy {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey("bluechat_device_key_v1", null) as? SecretKey) ?: run {
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            gen.init(KeyGenParameterSpec.Builder("bluechat_device_key_v1",
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build())
            gen.generateKey()
        }
    }
    val signing: KeyPair
    val agreement: KeyPair
    val id: String
    var alias: String
        get() = preferences.getString("alias", "Usuario ${id.take(6)}") ?: "Usuario ${id.take(6)}"
        set(value) { preferences.edit().putString("alias", value.trim().take(35)).apply() }

    init {
        val blob = preferences.getString("keys", null)
        val pairs = if (blob == null) {
            val sign = newEcKeyPair()
            val dh = newEcKeyPair()
            val j = JSONObject().apply {
                put("signPriv", b64(sign.private.encoded)); put("signPub", b64(sign.public.encoded))
                put("dhPriv", b64(dh.private.encoded)); put("dhPub", b64(dh.public.encoded))
            }
            preferences.edit().putString("keys", encryptLocal(j.toString())).apply()
            sign to dh
        } else {
            val j = JSONObject(decryptLocal(blob))
            parsePair(j.getString("signPub"), j.getString("signPriv")) to
                parsePair(j.getString("dhPub"), j.getString("dhPriv"))
        }
        signing = pairs.first
        agreement = pairs.second
        id = fingerprint(signing.public)
    }

    fun encryptLocal(value: String): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secureKey)
        return b64(cipher.iv + cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8)))
    }
    fun decryptLocal(value: String): String {
        val bytes = unb64(value)
        require(bytes.size >= 29)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secureKey, GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        return String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), StandardCharsets.UTF_8)
    }
    fun sign(value: String): String = b64(Signature.getInstance("SHA256withECDSA").run {
        initSign(signing.private); update(value.toByteArray(StandardCharsets.UTF_8)); sign()
    })
    fun verify(value: String, signature: String, publicKey: String): Boolean = try {
        Signature.getInstance("SHA256withECDSA").run {
            initVerify(parsePublic(publicKey)); update(value.toByteArray(StandardCharsets.UTF_8)); verify(unb64(signature))
        }
    } catch (_: Exception) { false }

    fun encryptFor(text: String, otherAgreement: String, otherId: String, messageId: String): String {
        val key = deriveKey(parsePublic(otherAgreement), otherId, messageId)
        val nonce = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, nonce))
        cipher.updateAAD(messageId.toByteArray())
        return b64(nonce + cipher.doFinal(text.toByteArray(StandardCharsets.UTF_8)))
    }
    fun decryptFrom(cipherText: String, senderAgreement: String, senderId: String, messageId: String): String {
        val bytes = unb64(cipherText)
        require(bytes.size >= 29)
        val key = deriveKey(parsePublic(senderAgreement), senderId, messageId)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, bytes.copyOfRange(0, 12)))
        cipher.updateAAD(messageId.toByteArray())
        return String(cipher.doFinal(bytes.copyOfRange(12, bytes.size)), StandardCharsets.UTF_8)
    }
    private fun deriveKey(other: PublicKey, otherId: String, messageId: String): SecretKeySpec {
        val keyAgreement = KeyAgreement.getInstance("ECDH")
        keyAgreement.init(agreement.private)
        keyAgreement.doPhase(other, true)
        val secret = keyAgreement.generateSecret()
        val ids = listOf(id, otherId).sorted().joinToString("|")
        val salt = MessageDigest.getInstance("SHA-256").digest("BlueChat-v1:$ids".toByteArray())
        val extract = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(salt, "HmacSHA256")) }.doFinal(secret)
        val expand = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(extract, "HmacSHA256")) }
            .doFinal("message:$messageId\u0001".toByteArray())
        return SecretKeySpec(expand.copyOf(32), "AES")
    }

    companion object {
        fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)
        fun unb64(text: String): ByteArray = Base64.decode(text, Base64.NO_WRAP)
        fun fingerprint(public: PublicKey): String = MessageDigest.getInstance("SHA-256")
            .digest(public.encoded).joinToString("") { "%02x".format(it) }
        fun parsePublic(encoded: String): PublicKey = KeyFactory.getInstance("EC")
            .generatePublic(X509EncodedKeySpec(unb64(encoded)))
        fun fingerprintEncoded(encoded: String): String = fingerprint(parsePublic(encoded))
        private fun newEcKeyPair(): KeyPair = KeyPairGenerator.getInstance("EC").run {
            initialize(ECGenParameterSpec("secp256r1")); generateKeyPair()
        }
        private fun parsePair(pub: String, priv: String): KeyPair = KeyPair(
            parsePublic(pub), KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(unb64(priv))))
    }
}
