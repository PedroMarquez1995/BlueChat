package com.bluechat.mesh

import android.app.Application
import com.bluechat.mesh.core.MeshCore
import com.bluechat.mesh.crypto.IdentityManager
import com.bluechat.mesh.db.LocalStore

class BlueChatApp : Application() {
    lateinit var identity: IdentityManager
        private set
    lateinit var database: LocalStore
        private set
    lateinit var core: MeshCore
        private set
    override fun onCreate() {
        super.onCreate()
        identity = IdentityManager(this)
        database = LocalStore(this, identity)
        core = MeshCore(this, identity, database)
    }
}
