package com.bluechat.mesh

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/** User-initiated visible foreground service. Android can still stop it under device policies. */
class MeshForegroundService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(NotificationChannel("bluechat_mesh", "Red Bluetooth Mesh", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = Notification.Builder(this, "bluechat_mesh")
            .setContentTitle("BlueChat · Red activa")
            .setContentText("Buscando vecinos Bluetooth y retransmitiendo mensajes")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(open).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(110, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } else startForeground(110, notification)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        (application as BlueChatApp).core.start()
        return START_STICKY
    }
    override fun onDestroy() {
        (application as BlueChatApp).core.stop()
        super.onDestroy()
    }
}
