package com.bluechat.mesh.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattServer
import android.bluetooth.BluetoothGattServerCallback
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.ParcelUuid
import com.bluechat.mesh.core.FragmentAssembler
import com.bluechat.mesh.core.FragmentCodec
import java.util.ArrayDeque
import java.util.UUID

/**
 * Android BLE point-to-point link layer used by BlueChat's own flood-and-store protocol.
 * It is NOT SIG Bluetooth Mesh. Discovery/advertisement/GATT can vary between manufacturers.
 * BLE operations are serialized PER LINK and every peer has a separate reassembler.
 */
@SuppressLint("MissingPermission")
class BleTransport(
    private val context: Context,
    private val onPacket: (String, ByteArray) -> Unit,
    private val onReady: (String) -> Unit,
    private val onStatus: (String, Int) -> Unit
) {
    companion object {
        val SERVICE: UUID = UUID.fromString("f0b3bbd0-ace4-4651-9a12-83a6b1e5c091")
        val RX: UUID = UUID.fromString("f0b3bbd1-ace4-4651-9a12-83a6b1e5c091")
        val TX: UUID = UUID.fromString("f0b3bbd2-ace4-4651-9a12-83a6b1e5c091")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }
    private val bluetooth = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter get() = bluetooth.adapter
    private val lock = Any()
    private var server: BluetoothGattServer? = null
    private var rx: BluetoothGattCharacteristic? = null
    private var tx: BluetoothGattCharacteristic? = null
    private var advertising: BluetoothLeAdvertiser? = null
    private var scanning = false

    private data class ClientLink(val gatt: BluetoothGatt, val assembler: FragmentAssembler = FragmentAssembler(),
                                  val queue: ArrayDeque<ByteArray> = ArrayDeque(), var busy: Boolean = false,
                                  var ready: Boolean = false, var mtu: Int = 23)
    private data class ServerLink(val device: BluetoothDevice, val assembler: FragmentAssembler = FragmentAssembler(),
                                  val queue: ArrayDeque<ByteArray> = ArrayDeque(), var busy: Boolean = false,
                                  var ready: Boolean = false, var mtu: Int = 23)
    private val clients = mutableMapOf<String, ClientLink>()
    private val servers = mutableMapOf<String, ServerLink>()

    fun supported(): Boolean = adapter != null && adapter.isEnabled && adapter.isMultipleAdvertisementSupported
    fun start() {
        if (!supported()) { onStatus("Bluetooth desactivado o publicidad BLE no compatible", 0); return }
        val gattServer = bluetooth.openGattServer(context, serverCallback)
        if (gattServer == null) { onStatus("No se pudo abrir el servidor GATT", 0); return }
        server = gattServer
        rx = BluetoothGattCharacteristic(RX, BluetoothGattCharacteristic.PROPERTY_WRITE,
            BluetoothGattCharacteristic.PERMISSION_WRITE)
        tx = BluetoothGattCharacteristic(TX, BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_READ)
        tx!!.addDescriptor(BluetoothGattDescriptor(CCCD,
            BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE))
        gattServer.addService(BluetoothGattService(SERVICE, BluetoothGattService.SERVICE_TYPE_PRIMARY).apply {
            addCharacteristic(rx!!); addCharacteristic(tx!!)
        })
        // Start advertising only after onServiceAdded confirms that GATT service exists.
    }
    fun stop() {
        try { if (scanning) adapter.bluetoothLeScanner?.stopScan(scanCallback) } catch (_: Exception) { }
        scanning = false
        try { advertising?.stopAdvertising(advertiseCallback) } catch (_: Exception) { }
        advertising = null
        synchronized(lock) {
            clients.values.forEach { try { it.gatt.disconnect(); it.gatt.close() } catch (_: Exception) { } }
            clients.clear(); servers.clear()
        }
        try { server?.clearServices(); server?.close() } catch (_: Exception) { }
        server = null
        onStatus("Red detenida", 0)
    }
    fun readyPeers(): Set<String> = synchronized(lock) {
        (clients.filterValues { it.ready }.keys + servers.filterValues { it.ready }.keys).toSet()
    }
    fun broadcast(payload: ByteArray, exclude: String? = null) {
        for (address in readyPeers()) if (address != exclude) send(address, payload)
    }
    fun send(address: String, payload: ByteArray) {
        synchronized(lock) {
            val client = clients[address]
            val peer = servers[address]
            if (client?.ready == true) {
                if (client.queue.size > 1000) return
                val frames = try { FragmentCodec.split(payload, client.mtu) } catch (_: Exception) { return }
                frames.forEach { client.queue.add(it) }
                pumpClient(client)
            } else if (peer?.ready == true) {
                if (peer.queue.size > 1000) return
                val frames = try { FragmentCodec.split(payload, peer.mtu) } catch (_: Exception) { return }
                frames.forEach { peer.queue.add(it) }
                pumpServer(peer)
            }
        }
    }

    private fun advertiseAndScan() {
        advertising = adapter.bluetoothLeAdvertiser
        try {
            advertising?.startAdvertising(
                AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM).setConnectable(true).build(),
                AdvertiseData.Builder().addServiceUuid(ParcelUuid(SERVICE)).setIncludeDeviceName(false).build(),
                advertiseCallback
            )
            val scanner = adapter.bluetoothLeScanner
            scanner?.startScan(listOf(ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE)).build()),
                ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_BALANCED).build(), scanCallback)
            scanning = scanner != null
            onStatus("Buscando teléfonos BlueChat cercanos", 0)
        } catch (t: Exception) { onStatus("Error BLE: ${t.message}", 0) }
    }
    private val advertiseCallback = object : AdvertiseCallback() {
        override fun onStartFailure(errorCode: Int) { onStatus("Publicidad BLE falló: $errorCode", readyPeers().size) }
    }
    private val scanCallback = object : ScanCallback() {
        override fun onScanFailed(errorCode: Int) { onStatus("Escaneo BLE falló: $errorCode", readyPeers().size) }
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device ?: return
            synchronized(lock) {
                if (clients.containsKey(device.address) || servers[device.address]?.ready == true || clients.size >= 6) return
                try {
                    val g = device.connectGatt(context, false, clientCallback, BluetoothDevice.TRANSPORT_LE)
                    if (g != null) clients[device.address] = ClientLink(g)
                } catch (_: Exception) { }
            }
        }
    }
    private val serverCallback = object : BluetoothGattServerCallback() {
        override fun onServiceAdded(status: Int, service: BluetoothGattService?) {
            if (status == BluetoothGatt.GATT_SUCCESS) advertiseAndScan()
            else onStatus("Error al registrar servicio GATT: $status", 0)
        }
        override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
            synchronized(lock) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    servers[device.address] = ServerLink(device)
                } else {
                    servers.remove(device.address)
                }
            }
            onStatus("Red Bluetooth activa", readyPeers().size)
        }
        override fun onDescriptorWriteRequest(device: BluetoothDevice, requestId: Int,
             descriptor: BluetoothGattDescriptor, preparedWrite: Boolean, responseNeeded: Boolean,
             offset: Int, value: ByteArray) {
            val ok = descriptor.uuid == CCCD && value.contentEquals(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            if (responseNeeded) server?.sendResponse(device, requestId,
                if (ok) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE, 0, null)
            if (ok) synchronized(lock) {
                servers[device.address]?.let { it.ready = true }
            }
            if (ok) { onStatus("Vecino conectado", readyPeers().size); onReady(device.address) }
        }
        override fun onCharacteristicWriteRequest(device: BluetoothDevice, requestId: Int,
            characteristic: BluetoothGattCharacteristic, preparedWrite: Boolean, responseNeeded: Boolean,
            offset: Int, value: ByteArray) {
            val ok = characteristic.uuid == RX && !preparedWrite && offset == 0
            if (responseNeeded) server?.sendResponse(device, requestId,
                if (ok) BluetoothGatt.GATT_SUCCESS else BluetoothGatt.GATT_FAILURE, 0, null)
            if (ok) {
                val payload = synchronized(lock) { servers[device.address]?.assembler?.accept(value) }
                if (payload != null) onPacket(device.address, payload)
            }
        }
        override fun onNotificationSent(device: BluetoothDevice, status: Int) {
            synchronized(lock) {
                servers[device.address]?.let { it.busy = false; if (it.queue.isNotEmpty()) it.queue.removeFirst(); pumpServer(it) }
            }
        }
        override fun onMtuChanged(device: BluetoothDevice, mtu: Int) {
            synchronized(lock) { servers[device.address]?.mtu = mtu }
        }
    }
    private val clientCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED && status == BluetoothGatt.GATT_SUCCESS) {
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS) {
                synchronized(lock) { clients.remove(gatt.device.address) }
                gatt.close()
                onStatus("Un vecino se desconectó", readyPeers().size)
            }
        }
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) return
            val characteristic = gatt.getService(SERVICE)?.getCharacteristic(TX) ?: return
            if (!gatt.setCharacteristicNotification(characteristic, true)) return
            val descriptor = characteristic.getDescriptor(CCCD) ?: return
            if (Build.VERSION.SDK_INT >= 33) {
                gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            } else {
                @Suppress("DEPRECATION")
                descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                @Suppress("DEPRECATION")
                gatt.writeDescriptor(descriptor)
            }
        }
        override fun onDescriptorWrite(gatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (descriptor.uuid != CCCD || status != BluetoothGatt.GATT_SUCCESS) return
            synchronized(lock) { clients[gatt.device.address]?.ready = true }
            onStatus("Vecino conectado", readyPeers().size)
            onReady(gatt.device.address)
            gatt.requestMtu(247)
        }
        override fun onMtuChanged(gatt: BluetoothGatt, mtu: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) synchronized(lock) { clients[gatt.device.address]?.mtu = mtu }
        }
        @Deprecated("Use API 33 overload")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid == TX) {
                @Suppress("DEPRECATION")
                val bytes = characteristic.value ?: return
                receiveClient(gatt.device.address, bytes)
            }
        }
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            if (characteristic.uuid == TX) receiveClient(gatt.device.address, value)
        }
        override fun onCharacteristicWrite(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            if (characteristic.uuid != RX) return
            synchronized(lock) {
                clients[gatt.device.address]?.let { it.busy = false; if (it.queue.isNotEmpty()) it.queue.removeFirst(); pumpClient(it) }
            }
        }
    }
    private fun receiveClient(address: String, data: ByteArray) {
        synchronized(lock) { clients[address]?.assembler?.accept(data) }?.let { onPacket(address, it) }
    }
    /** Called inside lock; sends at most one GATT write, waits for callback to send next. */
    private fun pumpClient(link: ClientLink) {
        if (link.busy || link.queue.isEmpty()) return
        val characteristic = link.gatt.getService(SERVICE)?.getCharacteristic(RX) ?: return
        link.busy = true
        val bytes = link.queue.first()
        val accepted = try {
            if (Build.VERSION.SDK_INT >= 33)
                link.gatt.writeCharacteristic(characteristic, bytes, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == 0
            else {
                @Suppress("DEPRECATION")
                characteristic.value = bytes
                characteristic.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                @Suppress("DEPRECATION")
                link.gatt.writeCharacteristic(characteristic)
            }
        } catch (_: Exception) { false }
        if (!accepted) { link.busy = false; link.queue.clear() }
    }
    private fun pumpServer(link: ServerLink) {
        if (link.busy || link.queue.isEmpty()) return
        val characteristic = tx ?: return
        link.busy = true
        val bytes = link.queue.first()
        val accepted = try {
            if (Build.VERSION.SDK_INT >= 33)
                server?.notifyCharacteristicChanged(link.device, characteristic, false, bytes) == 0
            else {
                @Suppress("DEPRECATION")
                characteristic.value = bytes
                @Suppress("DEPRECATION")
                server?.notifyCharacteristicChanged(link.device, characteristic, false) == true
            }
        } catch (_: Exception) { false }
        if (!accepted) { link.busy = false; link.queue.clear() }
    }
}
