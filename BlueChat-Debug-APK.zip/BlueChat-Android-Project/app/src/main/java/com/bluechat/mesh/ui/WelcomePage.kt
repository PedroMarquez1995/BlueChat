package com.bluechat.mesh.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.LockOutline
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun WelcomePage(onContinue: () -> Unit) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.Center) {
        Column(
            Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 26.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Box(
                Modifier.size(118.dp).clip(RoundedCornerShape(36.dp))
                    .background(Brush.linearGradient(listOf(Indigo, Color(0xFF164D9B), Night))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Bluetooth, contentDescription = null,
                    tint = Color.White, modifier = Modifier.size(69.dp))
            }
            Text("BlueChat", style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold)
            Text("Conectados sin Internet", color = MaterialTheme.colorScheme.primary,
                style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text("Habla con personas que tengan BlueChat utilizando Bluetooth. Los dispositivos intermedios pueden ayudar a retransmitir mensajes cifrados.",
                textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(9.dp))
            PanelCard {
                WelcomeFeature(Icons.Default.WifiOff, "Sin datos ni Wi-Fi",
                    "No hace falta SIM ni conexión a servidores")
                HorizontalDivider(modifier = Modifier.padding(vertical = 13.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                WelcomeFeature(Icons.Default.Hub, "Mensajería Mesh",
                    "Los mensajes pueden pasar por teléfonos cercanos")
                HorizontalDivider(modifier = Modifier.padding(vertical = 13.dp),
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                WelcomeFeature(Icons.Default.LockOutline, "Mensajes cifrados",
                    "Los contactos deben verificar sus identidades")
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Indigo,
                    contentColor = Color.White)) {
                Text("Comenzar con BlueChat", fontWeight = FontWeight.Bold)
            }
            Text("Versión experimental · La entrega no está garantizada",
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun WelcomeFeature(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, description: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(13.dp)) {
        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape) {
            Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
        }
        Column {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(description, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
