# BlueChat · Cambios de interfaz 2.0

## Archivos nuevos

- `app/src/main/java/com/bluechat/mesh/ui/BlueChatTheme.kt`: paletas Material 3 y tema persistente.
- `app/src/main/java/com/bluechat/mesh/ui/BlueChatScreen.kt`: encabezado, navegación, avatares, tarjetas y estados vacíos.
- `app/src/main/java/com/bluechat/mesh/ui/BlueChatPages.kt`: chats, cercanos, panel Mesh, ajustes y conversación.
- `app/src/main/java/com/bluechat/mesh/ui/WelcomePage.kt`: bienvenida inicial.

## Archivos adaptados

- `MainActivity.kt`: enlace entre interfaz y callbacks originales, persistencia del tema, ajustes de notificaciones.
- `core/MeshCore.kt`: solo agrega al estado de UI el último mensaje por contacto y el recuento de paquetes guardados.
- `db/LocalStore.kt`: dos consultas de lectura nuevas, sin cambios de esquema.
- `app/build.gradle.kts`: `versionCode=2`, `versionName=0.2.0`.
- `ic_bluechat.xml`, `colors.xml`, `strings.xml`: identidad visual actualizada.
- `.github/workflows/build.yml`: reemplaza el SDK action v3 por v4, igual que el workflow corregido.

## Sin cambios

- `ble/BleTransport.kt` y el manejo de conexiones Bluetooth.
- `core/Packet.kt`, `core/PacketJson.kt`, `core/FragmentCodec.kt` y sus pruebas.
- `crypto/IdentityManager.kt`: mismas claves y cifrado.
- `MeshForegroundService.kt` y permisos en `AndroidManifest.xml`.

No se añadieron permisos de Internet, SDK de terceros ni servidores. El funcionamiento Mesh entre dispositivos reales sigue pendiente de pruebas.
