package com.bluechat.mesh.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.bluechat.mesh.crypto.IdentityManager

/** Minimal local database. Messages are encrypted using the device's Android Keystore AES key. */
data class Contact(val id: String, val name: String, val signingPublic: String, val agreementPublic: String)
data class ChatMessage(val id: String, val peer: String, val outgoing: Boolean, val body: String, val created: Long, val status: String)

class LocalStore(context: Context, private val identity: IdentityManager) : SQLiteOpenHelper(context, "bluechat.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE contacts(id TEXT PRIMARY KEY,name TEXT NOT NULL, signing TEXT NOT NULL, dh TEXT NOT NULL)")
        db.execSQL("CREATE TABLE messages(id TEXT PRIMARY KEY,peer TEXT NOT NULL,outgoing INTEGER NOT NULL,body TEXT NOT NULL,created INTEGER NOT NULL,status TEXT NOT NULL)")
        db.execSQL("CREATE INDEX messages_peer_time ON messages(peer,created)")
        db.execSQL("CREATE TABLE packets(id TEXT PRIMARY KEY,data TEXT NOT NULL,expires INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    @Synchronized fun upsertContact(c: Contact) {
        writableDatabase.insertWithOnConflict("contacts", null, ContentValues().apply {
            put("id", c.id); put("name", c.name); put("signing", c.signingPublic); put("dh", c.agreementPublic)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }
    @Synchronized fun contact(id: String): Contact? = readableDatabase.rawQuery(
        "SELECT id,name,signing,dh FROM contacts WHERE id=?", arrayOf(id)).use { c ->
        if (c.moveToFirst()) Contact(c.getString(0), c.getString(1), c.getString(2), c.getString(3)) else null
    }
    @Synchronized fun contacts(): List<Contact> = readableDatabase.rawQuery(
        "SELECT id,name,signing,dh FROM contacts ORDER BY name LIMIT 250", null).use { c ->
        buildList { while (c.moveToNext()) add(Contact(c.getString(0), c.getString(1), c.getString(2), c.getString(3))) }
    }
    @Synchronized fun saveMessage(m: ChatMessage) {
        writableDatabase.insertWithOnConflict("messages", null, ContentValues().apply {
            put("id", m.id); put("peer", m.peer); put("outgoing", if (m.outgoing) 1 else 0)
            put("body", identity.encryptLocal(m.body)); put("created", m.created); put("status", m.status)
        }, SQLiteDatabase.CONFLICT_IGNORE)
    }
    @Synchronized fun setStatus(id: String, status: String) {
        writableDatabase.update("messages", ContentValues().apply { put("status", status) }, "id=?", arrayOf(id))
    }
    @Synchronized fun delivered(id: String, senderId: String) {
        writableDatabase.update("messages", ContentValues().apply { put("status", "Entregado") },
            "id=? AND peer=? AND outgoing=1", arrayOf(id, senderId))
    }
    @Synchronized fun messages(peer: String): List<ChatMessage> = readableDatabase.rawQuery(
        "SELECT id,peer,outgoing,body,created,status FROM messages WHERE peer=? ORDER BY created ASC LIMIT 500", arrayOf(peer)).use { c ->
        buildList {
            while (c.moveToNext()) {
                val body = try { identity.decryptLocal(c.getString(3)) } catch (_: Exception) { "[No se puede descifrar]" }
                add(ChatMessage(c.getString(0), c.getString(1), c.getInt(2) == 1, body, c.getLong(4), c.getString(5)))
            }
        }
    }
    /** Persistent deduplication. Store only signed packets after verification. */
    @Synchronized fun rememberPacket(id: String, json: String, expiry: Long): Boolean {
        val db = writableDatabase
        db.delete("packets", "expires<?", arrayOf(System.currentTimeMillis().toString()))
        val values = ContentValues().apply { put("id", id); put("data", json); put("expires", expiry) }
        val inserted = db.insertWithOnConflict("packets", null, values, SQLiteDatabase.CONFLICT_IGNORE) != -1L
        // Bound relay storage; oldest expiry discarded first.
        db.execSQL("DELETE FROM packets WHERE id IN (SELECT id FROM packets ORDER BY expires DESC LIMIT -1 OFFSET 600)")
        return inserted
    }
    @Synchronized fun pendingPackets(): List<String> = readableDatabase.rawQuery(
        "SELECT data FROM packets WHERE expires>? ORDER BY expires DESC LIMIT 150", arrayOf(System.currentTimeMillis().toString())).use { c ->
        buildList { while (c.moveToNext()) add(c.getString(0)) }
    }
}
