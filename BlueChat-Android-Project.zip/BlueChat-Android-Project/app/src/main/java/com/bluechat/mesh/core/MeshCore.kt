package com.bluechat.mesh.core

import android.content.Context
import android.util.Log
import com.bluechat.mesh.ble.BleTransport
import com.bluechat.mesh.crypto.IdentityManager
import com.bluechat.mesh.db.ChatMessage
import com.bluechat.mesh.db.Contact
import com.bluechat.mesh.db.LocalStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

/** Application-layer mesh: bounded gossip, persistent dedupe, and TTL-controlled encrypted relay. */
data class MeshUiState(
    val status: String = "Detenida", val active: Boolean = false, val peers: Int = 0,
    val contacts: List<Contact> = emptyList(), val selected: String? = null,
    val messages: List<ChatMessage> = emptyList()
)

class MeshCore(context: Context, val identity: IdentityManager, private val store: LocalStore) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val internal = MutableStateFlow(MeshUiState(contacts = store.contacts()))
    val ui: StateFlow<MeshUiState> = internal
    @Volatile private var running = false
    private val transport = BleTransport(context,
        onPacket = { address, data -> scope.launch { receive(address, data) } },
        onReady = { address -> scope.launch { peerReady(address) } },
        onStatus = { message, count -> update { it.copy(status = message, peers = count) } }
    )
    private fun update(modifier: (MeshUiState) -> MeshUiState) { synchronized(this) { internal.value = modifier(internal.value) } }
    fun refresh() {
        val c = store.contacts()
        val selected = internal.value.selected
        val messages = if (selected == null) emptyList() else store.messages(selected)
        update { it.copy(contacts = c, messages = messages) }
    }
    fun choose(id: String?) { update { it.copy(selected = id) }; scope.launch { refresh() } }
    fun updateAlias(value: String) {
        identity.alias = value
        if (running) scope.launch { publishProfile() }
    }
    fun start() {
        if (running) return
        try {
            if (!transport.supported()) {
                update { it.copy(active = false, status = "Activa Bluetooth en un teléfono con publicidad BLE") }
                return
            }
            running = true
            transport.start()
            update { it.copy(active = true, status = "Iniciando Bluetooth…") }
        } catch (error: Exception) {
            running = false
            update { it.copy(active = false, status = "Error: ${error.message}") }
        }
    }
    fun stop() {
        running = false
        try { transport.stop() } catch (_: Exception) { }
        update { it.copy(active = false, peers = 0, status = "Red detenida") }
    }
    private fun packet(type: String, recipient: String, payload: String, hours: Int = 24): Packet {
        val now = System.currentTimeMillis()
        val draft = Packet(UUID.randomUUID().toString(), type, identity.id, recipient,
            now, now + hours * 3_600_000L, 5, 0, payload, "")
        return draft.copy(signature = identity.sign(draft.signable()))
    }
    private fun publishProfile() {
        val profile = JSONObject().apply {
            put("name", identity.alias)
            put("signing", IdentityManager.b64(identity.signing.public.encoded))
            put("agreement", IdentityManager.b64(identity.agreement.public.encoded))
        }
        emit(packet("PROFILE", "", profile.toString(), 12))
    }
    private fun peerReady(address: String) {
        if (!running) return
        publishProfile()
        // The same encrypted packet can be forwarded when new peers appear later.
        store.pendingPackets().forEach { data ->
            val packet = PacketJson.decode(data) ?: return@forEach
            if (packet.canForward()) transport.send(address, PacketJson.encode(packet.relayed()).toByteArray(Charsets.UTF_8))
        }
        update { it.copy(peers = transport.readyPeers().size) }
    }
    fun sendMessage(recipient: Contact, text: String) {
        if (text.isBlank() || text.toByteArray(Charsets.UTF_8).size > 240) return
        scope.launch {
            try {
                val draft = packet("CHAT", recipient.id, "")
                val cipher = identity.encryptFor(text, recipient.agreementPublic, recipient.id, draft.id)
                val p = draft.copy(payload = cipher, signature = "").let {
                    it.copy(signature = identity.sign(it.signable()))
                }
                store.saveMessage(ChatMessage(p.id, recipient.id, true, text,
                    p.created, "Pendiente de entrega"))
                emit(p)
                refresh()
            } catch (ex: Exception) {
                Log.e("BlueChat", "Could not encrypt/send message", ex)
                update { it.copy(status = "No se pudo enviar: ${ex.message}") }
            }
        }
    }
    private fun emit(p: Packet) {
        val data = PacketJson.encode(p)
        store.rememberPacket(p.id, data, p.expires)
        transport.broadcast(PacketJson.encode(p.relayed()).toByteArray(Charsets.UTF_8))
    }
    private val applicationContext = context.applicationContext
    private fun notifyIncoming(name: String, body: String) {
        try {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            manager.createNotificationChannel(android.app.NotificationChannel(
                "bluechat_messages", "Mensajes BlueChat", android.app.NotificationManager.IMPORTANCE_DEFAULT))
            if (android.os.Build.VERSION.SDK_INT >= 33 &&
                applicationContext.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED) return
            val notification = android.app.Notification.Builder(applicationContext, "bluechat_messages")
                .setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle("BlueChat · $name")
                .setContentText(body.take(100))
                .setAutoCancel(true).build()
            manager.notify((System.currentTimeMillis() % 100_000).toInt() + 1000, notification)
        } catch (_: Exception) { /* Notifications are optional, never interrupt the message. */ }
    }
    private fun receive(fromAddress: String, bytes: ByteArray) {
        try {
            if (bytes.size > FragmentCodec.MAX_PAYLOAD) return
            val p = PacketJson.decode(bytes.toString(Charsets.UTF_8)) ?: return
            val now = System.currentTimeMillis()
            if (p.expires <= now || p.expires > p.created + 48 * 3_600_000L ||
                p.created > now + 300_000L || p.created < now - 48 * 3_600_000L) return
            if (p.hops > p.limit || p.sender == identity.id) return
            val source = if (p.type == "PROFILE") {
                val j = JSONObject(p.payload)
                val key = j.getString("signing")
                if (IdentityManager.fingerprintEncoded(key) != p.sender) return
                // Ensure that agreement key is a valid P-256 EC public key before accepting.
                IdentityManager.parsePublic(j.getString("agreement"))
                if (!identity.verify(p.signable(), p.signature, key)) return
                val name = j.optString("name", "Usuario").take(35).trim().ifBlank { "Usuario" }
                val c = Contact(p.sender, name, key, j.getString("agreement"))
                val known = store.contact(p.sender)
                if (known != null && (known.signingPublic != c.signingPublic || known.agreementPublic != c.agreementPublic)) return
                store.upsertContact(c)
                c
            } else {
                val c = store.contact(p.sender) ?: return
                if (!identity.verify(p.signable(), p.signature, c.signingPublic)) return
                c
            }
            if (!store.rememberPacket(p.id, PacketJson.encode(p), p.expires)) return
            if (p.type == "CHAT" && p.recipient == identity.id) {
                val decrypted = identity.decryptFrom(p.payload, source.agreementPublic, p.sender, p.id)
                if (decrypted.toByteArray().size > 240) return
                store.saveMessage(ChatMessage(p.id, p.sender, false, decrypted, p.created, "Recibido"))
                notifyIncoming(source.name, decrypted)
                emit(packet("ACK", p.sender, p.id, 12))
            }
            if (p.type == "ACK" && p.recipient == identity.id) {
                store.delivered(p.payload, p.sender)
            }
            refresh()
            if (p.canForward()) transport.broadcast(
                PacketJson.encode(p.relayed()).toByteArray(Charsets.UTF_8), exclude = fromAddress)
        } catch (error: Exception) {
            Log.w("BlueChat", "Rejected invalid Mesh message", error)
        }
    }
}
