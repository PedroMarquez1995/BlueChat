package com.bluechat.mesh

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bluechat.mesh.core.MeshUiState
import com.bluechat.mesh.db.Contact
import com.bluechat.mesh.db.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val app get() = application as BlueChatApp
    private val required: Array<String> get() = if (Build.VERSION.SDK_INT >= 31) arrayOf(
        Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_ADVERTISE
    ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (required.all { permission -> checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED }) requestBluetooth()
    }
    private val enableBluetooth = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (bluetoothEnabled()) startMesh()
    }
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        launchMeshService() // BlueChat can run even if notification permission was declined.
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val state by app.core.ui.collectAsState()
            BlueChatTheme {
                BlueChatScreen(state, app.identity.id, app.identity.alias,
                    onToggle = { if (state.active) stopMesh() else checkPermissions() },
                    onSelect = app.core::choose, onSend = app.core::sendMessage,
                    onRename = app.core::updateAlias)
            }
        }
    }
    private fun checkPermissions() {
        val missing = required.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) permissions.launch(missing.toTypedArray())
        else requestBluetooth()
    }
    @SuppressLint("MissingPermission")
    private fun bluetoothEnabled(): Boolean =
        (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true
    @SuppressLint("MissingPermission")
    private fun requestBluetooth() {
        if (bluetoothEnabled()) startMesh()
        else enableBluetooth.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
    }
    private fun startMesh() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else launchMeshService()
    }
    private fun launchMeshService() {
        startForegroundService(Intent(this, MeshForegroundService::class.java))
    }
    private fun stopMesh() = stopService(Intent(this, MeshForegroundService::class.java)).let { Unit }
}

private val DeepBlue = Color(0xFF0B5BC7)
@Composable private fun BlueChatTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) darkColorScheme(primary = Color(0xFF94C6FF), secondary = Color(0xFF70C7E8))
        else lightColorScheme(primary = DeepBlue, secondary = Color(0xFF127EA0), background = Color(0xFFF5F8FC)),
        content = content
    )
}

@Composable
private fun BlueChatScreen(state: MeshUiState, selfId: String, initialAlias: String,
                           onToggle: () -> Unit, onSelect: (String?) -> Unit,
                           onSend: (Contact, String) -> Unit, onRename: (String) -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val selected = state.contacts.firstOrNull { it.id == state.selected }
    Scaffold(
        topBar = {
            Surface(shadowElevation = 2.dp, color = MaterialTheme.colorScheme.surface) {
                Row(Modifier.fillMaxWidth().height(70.dp).padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    if (state.selected != null) {
                        IconButton(onClick = { onSelect(null) }) { Icon(Icons.Default.ArrowBack, "Volver") }
                    } else {
                        Icon(Icons.Default.Bluetooth, null, tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(selected?.name ?: "BlueChat", style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold)
                        Text(if (selected != null) "Mensajería cifrada · Entrega no garantizada" else state.status,
                            maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (state.selected == null) {
                        IconButton(onClick = onToggle) {
                            Icon(Icons.Default.PowerSettingsNew, if (state.active) "Detener red" else "Activar red",
                                tint = if (state.active) Color(0xFF209C64) else MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        },
        bottomBar = {
            if (state.selected == null) NavigationBar {
                val titles = listOf("Chats", "Contactos", "Red Mesh", "Ajustes")
                val icons = listOf(Icons.Default.Chat, Icons.Default.Groups, Icons.Default.Hub, Icons.Default.Settings)
                titles.forEachIndexed { index, name ->
                    NavigationBarItem(selected = tab == index, onClick = { tab = index },
                        icon = { Icon(icons[index], null) }, label = { Text(name) })
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (state.selected != null) {
                if (selected != null) Conversation(selected, state.messages, onSend)
                else Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Contacto no disponible") }
            } else when (tab) {
                0 -> ChatsTab(state, onToggle, onSelect)
                1 -> ContactsTab(state, onSelect)
                2 -> NetworkTab(state, onToggle)
                else -> SettingsTab(selfId, initialAlias, onRename)
            }
        }
    }
}
@Composable private fun BadgeText(value: String, positive: Boolean) {
    Surface(color = if (positive) Color(0xFFDAF7E8) else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(20.dp)) {
        Text(value, color = if (positive) Color(0xFF176842) else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            style = MaterialTheme.typography.labelSmall)
    }
}
@Composable private fun Title(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(bottom = 10.dp))
}
@Composable private fun StatusCard(state: MeshUiState, onToggle: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Hub, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Tu red sin Internet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f))
                BadgeText(if (state.active) "ACTIVA" else "DETENIDA", state.active)
            }
            Text("${state.peers} conexiones Bluetooth directas · ${state.contacts.size} identidades conocidas",
                style = MaterialTheme.typography.bodyMedium)
            Button(onClick = onToggle, modifier = Modifier.fillMaxWidth()) {
                Text(if (state.active) "Detener participación Mesh" else "Activar Bluetooth Mesh")
            }
        }
    }
}
@Composable private fun ContactRow(contact: Contact, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer,
            modifier = Modifier.size(50.dp)) {
            Box(contentAlignment = Alignment.Center) {
                Text(contact.name.take(1).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }
        Spacer(Modifier.width(13.dp))
        Column(Modifier.weight(1f)) {
            Text(contact.name, fontWeight = FontWeight.SemiBold)
            Text("ID ${contact.id.take(12)}… · Ruta no garantizada", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Icon(Icons.Default.Chat, "Abrir chat", tint = MaterialTheme.colorScheme.primary)
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
}
@Composable private fun ChatsTab(state: MeshUiState, onToggle: () -> Unit, onSelect: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item { StatusCard(state, onToggle); Spacer(Modifier.height(24.dp)); Title("Conversaciones") }
        if (state.contacts.isEmpty()) item { EmptyContacts() }
        items(state.contacts, key = { it.id }) { contact -> ContactRow(contact) { onSelect(contact.id) } }
        item { Spacer(Modifier.height(20.dp)); Text("Los mensajes viajan por teléfonos intermediarios cuando están disponibles. No se usan datos ni Wi-Fi.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
@Composable private fun EmptyContacts() {
    Column(Modifier.fillMaxWidth().padding(vertical = 35.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Default.Bluetooth, null, modifier = Modifier.size(54.dp), tint = MaterialTheme.colorScheme.primary)
        Text("Aún no hay contactos", fontWeight = FontWeight.SemiBold)
        Text("Activa la red en dos teléfonos con BlueChat. Los perfiles se intercambiarán mediante Bluetooth.",
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable private fun ContactsTab(state: MeshUiState, onSelect: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item { Title("Identidades conocidas"); Text("Esta lista incluye personas descubiertas directa o indirectamente mediante la red Mesh. No implica que estén conectadas ahora.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(12.dp)) }
        if (state.contacts.isEmpty()) item { EmptyContacts() }
        items(state.contacts, key = { it.id }) { c -> ContactRow(c) { onSelect(c.id) } }
    }
}
@Composable private fun NetworkTab(state: MeshUiState, onToggle: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("Estado de la red")
        StatusCard(state, onToggle)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Metric("${state.peers}", "Vecinos conectados", Modifier.weight(1f))
            Metric("${state.contacts.size}", "Identidades conocidas", Modifier.weight(1f))
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cómo retransmite BlueChat", fontWeight = FontWeight.Bold)
                Text("A → B → C", style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary)
                Text("Los teléfonos intermedios retransmiten paquetes cifrados con un límite de cinco saltos. Pueden conservarlos hasta su caducidad.")
                Text("La red no garantiza cobertura, entrega ni funcionamiento permanente en segundo plano.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
@Composable private fun Metric(value: String, caption: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.fillMaxWidth().padding(15.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            Text(caption, style = MaterialTheme.typography.labelMedium)
        }
    }
}
@Composable private fun SettingsTab(selfId: String, alias: String, onRename: (String) -> Unit) {
    var newAlias by remember(alias) { mutableStateOf(alias) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Title("Mi identidad")
        OutlinedTextField(value = newAlias, onValueChange = { newAlias = it.take(35) },
            label = { Text("Nombre visible") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = { onRename(newAlias) }, enabled = newAlias.isNotBlank()) { Text("Guardar nombre") }
        Text("Huella de identidad (SHA-256)", fontWeight = FontWeight.Medium)
        SelectionContainer { Text(selfId, style = MaterialTheme.typography.bodySmall) }
        HorizontalDivider()
        Text("Privacidad", fontWeight = FontWeight.Bold)
        Text("No necesitas SIM, cuenta, Wi-Fi ni Internet. El intercambio de perfiles divulga tu alias y claves públicas a nodos de la red.")
        Text("Versión experimental 0.1.0 · No usar para comunicaciones críticas.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
@Composable private fun Conversation(contact: Contact, messages: List<ChatMessage>, onSend: (Contact, String) -> Unit) {
    var input by remember(contact.id) { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), reverseLayout = true) {
            items(messages.reversed(), key = { it.id }) { message ->
                Column(Modifier.fillMaxWidth(), horizontalAlignment = if (message.outgoing) Alignment.End else Alignment.Start) {
                    Surface(color = if (message.outgoing) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(17.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                            Text(message.body)
                            Text("${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(message.created))} · ${message.status}",
                                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(value = input, onValueChange = { input = it.take(240) },
                modifier = Modifier.weight(1f), placeholder = { Text("Mensaje Bluetooth…") }, maxLines = 4,
                shape = RoundedCornerShape(24.dp))
            Spacer(Modifier.width(8.dp))
            FilledIconButton(onClick = { if (input.isNotBlank()) { onSend(contact, input.trim()); input = "" } },
                enabled = input.isNotBlank()) { Icon(Icons.Default.Send, "Enviar mensaje") }
        }
    }
}
