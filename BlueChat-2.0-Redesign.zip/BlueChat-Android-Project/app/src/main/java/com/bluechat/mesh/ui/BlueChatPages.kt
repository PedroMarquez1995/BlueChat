package com.bluechat.mesh.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bluechat.mesh.core.MeshUiState
import com.bluechat.mesh.db.ChatMessage
import com.bluechat.mesh.db.Contact
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun shortTime(time: Long): String =
    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(time))

@Composable
internal fun MeshHero(state: MeshUiState, onToggleMesh: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1748A2), Color(0xFF122C59), Color(0xFF0D1C37))))
    ) {
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Surface(shape = RoundedCornerShape(13.dp), color = Color.White.copy(alpha = 0.14f)) {
                    Box(Modifier.size(42.dp), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Hub, contentDescription = null, tint = Color.White)
                    }
                }
                Column(Modifier.weight(1f)) {
                    Text("TU RED BLUECHAT", color = Color.White.copy(alpha = 0.7f),
                        style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Text(if (state.active) "Red en funcionamiento" else "Conexión sin activar",
                        color = Color.White, style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold)
                }
                Surface(color = if (state.active) Success.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.12f),
                    shape = CircleShape) {
                    Text(if (state.active) "ACTIVA" else "DETENIDA",
                        color = if (state.active) Color(0xFF9BF6BE) else Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp))
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("${state.peers}", color = Color.White,
                            style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        Text("vecinos conectados", color = Color.White.copy(alpha = 0.75f),
                            modifier = Modifier.padding(bottom = 5.dp), style = MaterialTheme.typography.labelMedium)
                    }
                    Text("Sin Wi-Fi, datos ni servidores", color = Color.White.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.bodySmall)
                }
                Icon(Icons.Default.Bluetooth, contentDescription = null,
                    tint = Electric.copy(alpha = 0.85f), modifier = Modifier.size(42.dp))
            }
            Button(
                onClick = onToggleMesh,
                modifier = Modifier.fillMaxWidth().height(46.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (state.active) Color.White.copy(alpha = 0.16f) else Electric,
                    contentColor = if (state.active) Color.White else Night
                )
            ) {
                Icon(if (state.active) Icons.Default.StopCircle else Icons.Default.PlayArrow,
                    contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (state.active) "Detener red Mesh" else "Activar red Bluetooth",
                    fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
internal fun ChatsPage(
    state: MeshUiState, onToggleMesh: () -> Unit, onSelect: (String) -> Unit, onNearby: () -> Unit
) {
    val contacts = remember(state.contacts, state.latestMessages) {
        state.contacts.sortedWith(compareByDescending<Contact> {
            state.latestMessages[it.id]?.created ?: 0L
        }.thenBy { it.name.lowercase() })
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)
    ) {
        item { MeshHero(state, onToggleMesh) }
        item { SectionHeading("Conversaciones", "${contacts.size} contactos") }
        if (contacts.isEmpty()) {
            item {
                PanelCard {
                    EmptyPanel(Icons.Default.Forum, "Todavía no hay conversaciones",
                        "Activa Bluetooth en otros teléfonos con BlueChat para descubrir sus identidades.") {
                        OutlinedButton(onClick = onNearby) { Text("Explorar contactos") }
                    }
                }
            }
        } else {
            items(contacts, key = { it.id }) { contact ->
                ChatContactRow(contact, state.latestMessages[contact.id]) { onSelect(contact.id) }
            }
        }
        item {
            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Icon(Icons.Default.Info, contentDescription = null,
                    modifier = Modifier.size(17.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("La entrega depende de que exista una ruta Bluetooth. Los contactos conocidos no necesariamente están conectados ahora.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun ChatContactRow(contact: Contact, last: ChatMessage?, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(13.dp)) {
            InitialAvatar(contact.name)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text(contact.name, style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    last?.body?.let { if (last.outgoing) "Tú: $it" else it } ?: "Sin mensajes · Toca para conversar",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (last != null) {
                    Text(shortTime(last.created), style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    if (last.outgoing) {
                        Icon(if (last.status == "Entregado") Icons.Default.DoneAll else Icons.Default.Schedule,
                            contentDescription = last.status,
                            modifier = Modifier.size(17.dp),
                            tint = if (last.status == "Entregado") Success
                                else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    Icon(Icons.Default.ChevronRight, contentDescription = "Abrir conversación",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

@Composable
internal fun NearbyPage(state: MeshUiState, onToggleMesh: () -> Unit, onSelect: (String) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeading("Explorar BlueChat")
            Spacer(Modifier.height(7.dp))
            Text("Busca dispositivos con BlueChat. Las identidades también pueden llegar a través de otros nodos.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        item {
            PanelCard {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(17.dp)) {
                        Box(Modifier.size(60.dp), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.BluetoothSearching, contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(31.dp))
                        }
                    }
                    Column(Modifier.weight(1f)) {
                        Text(if (state.active) "Exploración en marcha" else "Exploración detenida",
                            fontWeight = FontWeight.SemiBold)
                        Text("${state.peers} conexiones directas · ${state.contacts.size} identidades conocidas",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Spacer(Modifier.height(15.dp))
                LabelPill(if (state.active) "Bluetooth Mesh habilitado" else "Red sin activar", state.active)
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = onToggleMesh, modifier = Modifier.fillMaxWidth()) {
                    Icon(if (state.active) Icons.Default.Stop else Icons.Default.Bluetooth,
                        contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (state.active) "Detener exploración" else "Activar descubrimiento")
                }
            }
        }
        item { SectionHeading("Personas descubiertas", "${state.contacts.size}") }
        if (state.contacts.isEmpty()) {
            item {
                EmptyPanel(Icons.Default.PeopleOutline, "Nadie descubierto aún",
                    "Instala BlueChat en otro Android, activa Bluetooth y enciende la red en ambos equipos.")
            }
        } else {
            items(state.contacts, key = { it.id }) { contact ->
                Surface(color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(19.dp),
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(contact.id) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        InitialAvatar(contact.name, 48.dp)
                        Column(Modifier.weight(1f)) {
                            Text(contact.name, fontWeight = FontWeight.SemiBold)
                            Text("ID ${contact.id.take(12)}… · presencia no verificada",
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.labelSmall)
                        }
                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Iniciar chat",
                            tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item {
            Text("Los nombres de esta lista no prueban cercanía física ni una conexión activa. BlueChat no calcula distancias exactas.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MetricCard(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                       modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
internal fun MeshPage(state: MeshUiState, onToggleMesh: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)) {
        SectionHeading("Estado de tu red")
        MeshHero(state, onToggleMesh)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            MetricCard(state.peers.toString(), "Vecinos conectados", Icons.Default.Bluetooth,
                modifier = Modifier.weight(1f))
            MetricCard(state.contacts.size.toString(), "Identidades conocidas", Icons.Default.People,
                modifier = Modifier.weight(1f))
        }
        MetricCard(state.storedPackets.toString(), "Paquetes Mesh guardados en este dispositivo",
            Icons.Default.Inventory2, modifier = Modifier.fillMaxWidth())
        PanelCard {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary)
                Text("Así viajan los mensajes", style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(15.dp))
            Surface(color = MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Text("A     →     B     →     C",
                    modifier = Modifier.padding(18.dp),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(9.dp))
            Text("Ejemplo ilustrativo, no una ruta detectada. Los nodos intermedios pueden retransmitir paquetes cifrados si existe una cadena compatible.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
        PanelCard {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Icon(Icons.Default.Shield, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary)
                Text("Transporte y privacidad", style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(state.status, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(8.dp))
            Text("El número de retransmisiones completadas y los nodos en línea por identidad no están disponibles en esta versión. No se muestran estadísticas estimadas.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
internal fun SettingsPage(
    selfId: String,
    alias: String,
    state: MeshUiState,
    themeMode: String,
    onRename: (String) -> Unit,
    onThemeChanged: (String) -> Unit,
    onToggleMesh: () -> Unit,
    onOpenNotificationSettings: () -> Unit
) {
    var editedAlias by remember(alias) { mutableStateOf(alias) }
    val clipboard = LocalClipboardManager.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        SectionHeading("Mi perfil")
        PanelCard {
            Row(verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(13.dp)) {
                InitialAvatar(alias, 64.dp)
                Column {
                    Text(alias, style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold)
                    Text("Identidad local · Sin número telefónico",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(
                value = editedAlias,
                onValueChange = { editedAlias = it.take(35) },
                label = { Text("Nombre visible") }, singleLine = true,
                shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Button(onClick = { onRename(editedAlias.trim()) },
                enabled = editedAlias.isNotBlank() && editedAlias.trim() != alias,
                modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text("Guardar nombre")
            }
        }
        SectionHeading("Personalización")
        PanelCard {
            Text("Apariencia", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("dark" to "Oscuro", "light" to "Claro", "system" to "Sistema").forEach { (mode, label) ->
                    FilterChip(selected = themeMode == mode, onClick = { onThemeChanged(mode) },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) })
                }
            }
        }
        SectionHeading("Conectividad")
        PanelCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Hub, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Participación Mesh", fontWeight = FontWeight.SemiBold)
                    Text(if (state.active) "Servicio activo" else "Servicio detenido",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = state.active, onCheckedChange = { onToggleMesh() })
            }
            Spacer(Modifier.height(10.dp))
            Text("Al activarla, el teléfono puede participar en retransmisiones. No hay todavía un interruptor separado para el modo repetidor.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionHeading("Privacidad")
        PanelCard {
            Text("Huella de identidad", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(7.dp))
            SelectionContainer {
                Text(selfId, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = { clipboard.setText(AnnotatedString(selfId)) },
                modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.ContentCopy, contentDescription = null,
                    modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(8.dp))
                Text("Copiar identificador")
            }
            Spacer(Modifier.height(9.dp))
            Text("Los contactos se descubren mediante claves públicas. Comprueba las huellas de identidad antes de intercambiar información sensible.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        SectionHeading("Notificaciones")
        PanelCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.NotificationsNone, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Permisos de notificación", fontWeight = FontWeight.SemiBold)
                    Text("Administrar desde Android",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onOpenNotificationSettings) {
                    Icon(Icons.Default.OpenInNew, contentDescription = "Abrir ajustes de notificaciones")
                }
            }
        }
        Text("BlueChat 0.2.0 · Interfaz 2.0 · Versión experimental", fontWeight = FontWeight.Medium,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Sin Internet ni servidores. La retransmisión Mesh requiere pruebas en teléfonos reales y no garantiza la entrega.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
    }
}

@Composable
internal fun ConversationPage(contact: Contact, messages: List<ChatMessage>,
                              onSend: (Contact, String) -> Unit) {
    var input by remember(contact.id) { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(contact.id, messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(0)
    }
    Column(Modifier.fillMaxSize().imePadding()) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(horizontal = 16.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Lock, contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                Text("Cifrado de extremo a extremo · Entrega no garantizada",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                EmptyPanel(Icons.Default.ChatBubbleOutline, "Empieza una conversación",
                    "Escribe un mensaje. BlueChat intentará enviarlo cuando encuentre una ruta Bluetooth disponible.")
            }
        } else {
            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                reverseLayout = true,
                contentPadding = PaddingValues(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages.asReversed(), key = { it.id }) { message ->
                    MessageBubble(message)
                }
            }
        }
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 1.dp) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { candidate ->
                        if (candidate.toByteArray(Charsets.UTF_8).size <= 240) input = candidate
                    },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Mensaje por Bluetooth…") },
                    maxLines = 4,
                    shape = RoundedCornerShape(24.dp)
                )
                FilledIconButton(
                    onClick = {
                        val value = input.trim()
                        if (value.isNotEmpty()) {
                            onSend(contact, value)
                            input = ""
                        }
                    },
                    enabled = input.isNotBlank(),
                    shape = CircleShape,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Indigo, contentColor = Color.White),
                    modifier = Modifier.size(52.dp)
                ) {
                    Icon(Icons.Default.Send, contentDescription = "Enviar mensaje")
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val outgoing = message.outgoing
    val delivered = message.status == "Entregado"
    Row(Modifier.fillMaxWidth(),
        horizontalArrangement = if (outgoing) Arrangement.End else Arrangement.Start) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 18.dp, topEnd = 18.dp,
                bottomEnd = if (outgoing) 5.dp else 18.dp,
                bottomStart = if (outgoing) 18.dp else 5.dp
            ),
            color = if (outgoing) Indigo else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 310.dp)
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(message.body,
                    color = if (outgoing) Color.White else MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.bodyMedium)
                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(shortTime(message.created),
                        color = if (outgoing) Color.White.copy(alpha = 0.75f)
                            else MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.labelSmall)
                    if (outgoing) {
                        Icon(if (delivered) Icons.Default.DoneAll else Icons.Default.Schedule,
                            contentDescription = message.status,
                            tint = if (delivered) Color(0xFFA7F3D0) else Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(14.dp))
                    }
                }
                if (outgoing && !delivered) {
                    Text(message.status,
                        color = Color.White.copy(alpha = 0.72f),
                        style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
